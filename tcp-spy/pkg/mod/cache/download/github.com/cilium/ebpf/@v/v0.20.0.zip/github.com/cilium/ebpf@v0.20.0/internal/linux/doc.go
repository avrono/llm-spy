// Package linux contains OS specific wrappers around package unix.
package linux
