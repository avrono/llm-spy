package platform

const Native = Linux
