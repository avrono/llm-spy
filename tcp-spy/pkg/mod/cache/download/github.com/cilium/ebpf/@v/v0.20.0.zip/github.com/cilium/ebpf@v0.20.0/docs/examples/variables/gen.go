package main

//go:generate go tool bpf2go variables variables.c
