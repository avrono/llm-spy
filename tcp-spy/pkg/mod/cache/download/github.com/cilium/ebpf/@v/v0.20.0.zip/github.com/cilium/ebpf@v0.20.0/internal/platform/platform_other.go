//go:build !linux && !windows

package platform

const Native = ""
