// Package rlimit allows raising RLIMIT_MEMLOCK if necessary for the use of BPF.
package rlimit
