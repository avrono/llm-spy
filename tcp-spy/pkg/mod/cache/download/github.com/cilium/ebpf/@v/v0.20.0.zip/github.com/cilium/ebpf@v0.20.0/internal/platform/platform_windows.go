package platform

const Native = Windows
