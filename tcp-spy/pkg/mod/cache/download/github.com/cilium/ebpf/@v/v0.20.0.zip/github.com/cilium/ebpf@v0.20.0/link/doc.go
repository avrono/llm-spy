// Package link allows attaching eBPF programs to various kernel hooks.
package link
