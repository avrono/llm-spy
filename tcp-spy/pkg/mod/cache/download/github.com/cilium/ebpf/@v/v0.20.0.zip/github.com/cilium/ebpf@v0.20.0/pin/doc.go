// Package pin provides utility functions for working with pinned objects on bpffs.

package pin
